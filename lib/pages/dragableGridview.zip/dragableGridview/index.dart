/*
 * @Author: MarioGo
 * @Date: 2021-10-05 09:13:08
 * @LastEditTime: 2021-10-05 09:53:36
 * @LastEditors: MarioGo
 * @Description: 文件描述
 * @FilePath: /flutter_24/lib/pages/dragableGridview/index.dart
 * 可以输入预定的版权声明、个性签名、空行等
 */
import 'package:flutter/material.dart';
import 'package:flutter_24/pages/dragableGridview/packages/dragablegridview_flutter.dart';

import 'gridviewitembin.dart';

class DragAbleGridViewPage extends StatefulWidget {
  DragAbleGridViewPage({Key? key}) : super(key: key);

  @override
  _DragAbleGridViewPageState createState() => _DragAbleGridViewPageState();
}

class _DragAbleGridViewPageState extends State<DragAbleGridViewPage> {
  //创建状态
  List<ItemBin> itemBins = [];
  String actionTxtEdit = "编辑";
  String actionTxtComplete = "完成";
  String? actionTxt;
  // var editSwitchController = EditSwitchController();
  final List<String> heroes = [
    "鲁班",
    "虞姬",
    "甄姬",
    "黄盖",
    "张飞",
    "关羽",
    "刘备",
    "曹操",
    "赵云",
    "孙策",
    "庄周",
    "廉颇",
    "后裔",
    "妲己",
    "荆轲",
  ];

  @override
  void initState() {
    super.initState();
    actionTxt = actionTxtEdit;
    heroes.forEach((heroName) {
      itemBins.add(new ItemBin(heroName));
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: new Text("可拖拽GridView"),
        actions: <Widget>[
          Center(
            child: GestureDetector(
              child: Container(
                child: Text(
                  actionTxt!,
                  style: TextStyle(fontSize: 19),
                ),
                margin: EdgeInsets.only(right: 12),
              ),
              onTap: () {
                //todo:写编辑逻辑
                changeActionState();
                // editSwitchController.editStateChanged();
              },
            ),
          )
        ],
      ),
      body: DragAbleGridView(
        mainAxisSpacing: 10.0,
        crossAxisSpacing: 10.0,
        childAspectRatio: 1.8,
        crossAxisCount: 4,
        itemBins: itemBins,
        // editSwitchController: () {}, // editSwitchController,
        /******************************new parameter*********************************/
        isOpenDragAble: true,
        animationDuration: 300, //milliseconds
        longPressDuration: 800, //milliseconds
        /******************************new parameter*********************************/
        deleteIcon:
            new Image.asset("images/close.png", width: 15.0, height: 15.0),
        // child: null,
        editChangeListener: () {
          changeActionState();
        },
      ),
    );
  }

  //改变状态
  void changeActionState() {
    if (actionTxt == actionTxtEdit) {
      setState(() {
        actionTxt = actionTxtComplete;
      });
    } else {
      setState(() {
        actionTxt = actionTxtEdit;
      });
    }
  }
}
