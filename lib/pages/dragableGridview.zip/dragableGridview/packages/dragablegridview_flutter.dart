/*
 * @Author: MarioGo
 * @Date: 2021-10-05 09:30:24
 * @LastEditTime: 2021-10-05 09:50:17
 * @LastEditors: MarioGo
 * @Description: 文件描述
 * @FilePath: /flutter_24/lib/pages/dragableGridview/packages/dragablegridview_flutter.dart
 * 可以输入预定的版权声明、个性签名、空行等
 */

import 'dart:async';

import 'package:flutter/material.dart';

import 'dragablegridviewbin.dart';

//创建子组件
typedef CreateChild = Widget Function(int position);
//编辑状态监听
typedef EditChangeListener();
// 删除监听
typedef DeleteIconClickListener = void Function(int index);

class DragAbleGridView<T extends DragAbleGridViewBin> extends StatefulWidget {
  //构造函数参
  final CreateChild child;

  ///GridView一行显示几个child
  final int crossAxisCount;

  ///为了便于计算 Item之间的空隙都用crossAxisSpacing
  final double crossAxisSpacing;
  final double mainAxisSpacing;
  //cross-axis to the main-axis
  final double childAspectRatio;

  ///编辑开关控制器，可通过点击按钮触发编辑
  final EditSwitchController editSwitchController;

  ///长按触发编辑状态，可监听状态来改变编辑按钮（编辑开关 ，通过按钮触发编辑）的状态
  final EditChangeListener editChangeListener;
  final bool isOpenDragAble;
  final int animationDuration;
  final int longPressDuration;

  ///删除按钮
  final Widget? deleteIcon;
  final DeleteIconClickListener? deleteIconClickListener;

  var itemBins;

  DragAbleGridView({
    required this.child,
    required this.itemBins,
    this.crossAxisCount: 4,
    this.childAspectRatio: 1.0,
    this.mainAxisSpacing: 0.0,
    this.crossAxisSpacing: 0.0,
    this.editSwitchController,
    required this.editChangeListener,
    this.isOpenDragAble: false,
    this.animationDuration: 300,
    this.longPressDuration: 800,
    this.deleteIcon,
    this.deleteIconClickListener,
  }) : assert(
          child != null,
          itemBins != null,
        );

  @override
  _DragAbleGridViewState createState() => _DragAbleGridViewState();
}

class _DragAbleGridViewState extends State<DragAbleGridView> {
  var physics = new ScrollPhysics();
  double? screenWidth;
  double? screenHeight;

  ///在拖动过程中Item position 的位置记录
  List<int> itemPositions;

  ///下面4个变量具体看onTapDown（）方法里面的代码，有具体的备注
  double itemWidth = 0.0;
  double itemHeight = 0.0;
  double itemWidthChild = 0.0;
  double itemHeightChild = 0.0;

  ///下面2个变量具体看onTapDown（）方法里面的代码，有具体的备注
  double blankSpaceHorizontal = 0.0;
  double blankSpaceVertical = 0.0;
  double xBlankPlace = 0.0;
  double yBlankPlace = 0.0;

  Animation<double>? animation;
  AnimationController? controller;
  int? startPosition;
  int? endPosition;
  bool isRest = false;

  ///覆盖超过1/5则触发动画，宽和高只要有一个满足就可以触发
  //double areaCoverageRatio=1/5;
  Timer? timer;
  bool isRemoveItem = false;
  bool isHideDeleteIcon = true;
  Future? _future;
  double xyDistance = 0.0;
  double yDistance = 0.0;
  double xDistance = 0.0;

  @override
  void initState() {
    super.initState();
    widget.editSwitchController.dragAbleGridViewState = this;
    controller = AnimationController(
        duration: Duration(milliseconds: widget.animationDuration),
        vsync: this);
    animation = new Tween(begin: 0.0, end: 1.0).animate(controller!)
      ..addListener(() {
        T offsetBin;
        int childWidgetPosition;

        if (isRest) {
          if (startPosition! > endPosition!) {
            for (int i = endPosition!; i < startPosition!; i++) {
              childWidgetPosition = itemPositions[i];
              offsetBin = widget.itemBins[childWidgetPosition];
              //图标向右 下移动
              if ((i + 1) % widget.crossAxisCount == 0) {
                offsetBin.lastTimePositionX = -(screenWidth - itemWidth) * 1 +
                    offsetBin.lastTimePositionX;
                offsetBin.lastTimePositionY =
                    (itemHeight + widget.mainAxisSpacing) * 1 +
                        offsetBin.lastTimePositionY;
              } else {
                offsetBin.lastTimePositionX =
                    (itemWidth + widget.crossAxisSpacing) * 1 +
                        offsetBin.lastTimePositionX;
              }
            }
          } else {
            for (int i = startPosition + 1; i <= endPosition!; i++) {
              childWidgetPosition = itemPositions[i];
              offsetBin = widget.itemBins[childWidgetPosition];
              //图标向左 上移动
              if (i % widget.crossAxisCount == 0) {
                offsetBin.lastTimePositionX =
                    (screenWidth - itemWidth) * 1 + offsetBin.lastTimePositionX;
                offsetBin.lastTimePositionY =
                    -(itemHeight + widget.mainAxisSpacing) * 1 +
                        offsetBin.lastTimePositionY;
              } else {
                offsetBin.lastTimePositionX =
                    -(itemWidth + widget.crossAxisSpacing) * 1 +
                        offsetBin.lastTimePositionX;
              }
            }
          }
          return;
        }
        double animationValue = animation!.value;

        //此代码和上面的代码一样，但是不能提成方法调用 ，已经测试调用方法不会生效
        //startPosition大于endPosition表明目标位置在上方，图标需要向后退一格
        if (startPosition > endPosition!) {
          for (int i = endPosition!; i < startPosition!; i++) {
            childWidgetPosition = itemPositions[i];
            offsetBin = widget.itemBins[childWidgetPosition];
            //图标向左 下移动；如果图标处在最右侧，那需要向下移动一层，移动到下一层的最左侧，（开头的地方）
            if ((i + 1) % widget.crossAxisCount == 0) {
              setState(() {
                offsetBin.dragPointX =
                    -xyDistance * animationValue + offsetBin.lastTimePositionX;
                offsetBin.dragPointY =
                    yDistance * animationValue + offsetBin.lastTimePositionY;
              });
            } else {
              setState(() {
                //↑↑↑如果图标不是处在最右侧，只需要向右移动即可
                offsetBin.dragPointX =
                    xDistance * animationValue + offsetBin.lastTimePositionX;
              });
            }
          }
        }
        //当目标位置在下方时 ，图标需要向前前进一个
        else {
          for (int i = startPosition + 1; i <= endPosition!; i++) {
            childWidgetPosition = itemPositions[i];
            offsetBin = widget.itemBins[childWidgetPosition];
            //图标向右 上移动；如果图标处在最左侧，那需要向上移动一层
            if (i % widget.crossAxisCount == 0) {
              setState(() {
                offsetBin.dragPointX =
                    xyDistance * animationValue + offsetBin.lastTimePositionX;
                offsetBin.dragPointY =
                    -yDistance * animationValue + offsetBin.lastTimePositionY;
              });
            } else {
              setState(() {
                //↑↑↑如果图标不是处在最左侧，只需要向左移动即可
                offsetBin.dragPointX =
                    -xDistance * animationValue + offsetBin.lastTimePositionX;
              });
            }
          }
        }
      });
    animation!.addStatusListener((animationStatus) {
      if (animationStatus == AnimationStatus.completed) {
        setState(() {});
        isRest = true;
        controller!.reset();
        isRest = false;

        if (isRemoveItem) {
          isRemoveItem = false;
          itemPositions.removeAt(startPosition!);
          onPanEndEvent(startPosition);
        } else {
          int dragPosition = itemPositions[startPosition!];
          itemPositions.removeAt(startPosition!);
          itemPositions.insert(endPosition!, dragPosition);
          //手指未抬起来（可能会继续拖动），这时候end的位置等于Start的位置
          startPosition = endPosition;
        }
      } else if (animationStatus == AnimationStatus.forward) {}
    });
    _initItemPositions();
  }

  void _initItemPositions() {
    itemPositions = [];
    for (int i = 0; i < widget.itemBins.length; i++) {
      itemPositions.add(i);
    }
  }

  @override
  void didUpdateWidget(DragAbleGridView<DragAbleGridViewBin> oldWidget) {
    if (itemPositions.length != widget.itemBins.length) {
      _initItemPositions();
    }
    super.didUpdateWidget(oldWidget);
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    Size screenSize = MediaQuery.of(context).size;
    screenWidth = screenSize.width;
    screenHeight = screenSize.height;
  }

  @override
  Widget build(BuildContext context) {
    return Container();
  }

  ///拖动结束后，根据 itemPositions 里面的排序，将itemBins重新排序
  ///并重新初始化 itemPositions
  @override
  void onPanEndEvent(index) async {
    widget.itemBins[index].dragAble = false;
    if (controller!.isAnimating) {
      await _future;
    }
    setState(() {
      List itemBi = [];
      // T bin;
      // for (int i = 0; i < itemPositions.length; i++) {
      //   bin = widget.itemBins[itemPositions[i]];
      //   bin.dragPointX = 0.0;
      //   bin.dragPointY = 0.0;
      //   bin.lastTimePositionX = 0.0;
      //   bin.lastTimePositionY = 0.0;
      //   itemBi.add(bin);
      // }
      widget.itemBins.clear();
      widget.itemBins.addAll(itemBi);
      _initItemPositions();
    });
  }
}
