/*
 * @Author: MarioGo
 * @Date: 2021-10-05 09:13:55
 * @LastEditTime: 2021-10-05 09:13:55
 * @LastEditors: MarioGo
 * @Description: 文件描述
 * @FilePath: /flutter_24/lib/pages/dragableGridview/packages/dragablegridviewbin.dart
 * 可以输入预定的版权声明、个性签名、空行等
 */
import 'package:flutter/material.dart';

//创建每一个拖动类
class DragAbleGridViewBin {
  double dragPointX = 0.0;
  double dragPointY = 0.0;
  double lastTimePositionX = 0.0;
  double lastTimePositionY = 0.0;
  GlobalKey containerKey = new GlobalKey();
  GlobalKey containerKeyChild = new GlobalKey();
  bool isLongPress = false;
  bool dragAble = false;

  ///是否隐藏，默认不隐藏
  bool offstage = false;
}
