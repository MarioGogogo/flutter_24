/*
 * @Author: MarioGo
 * @Date: 2021-10-05 09:13:31
 * @LastEditTime: 2021-10-05 09:14:34
 * @LastEditors: MarioGo
 * @Description: 文件描述
 * @FilePath: /flutter_24/lib/pages/dragableGridview/gridviewitembin.dart
 * 可以输入预定的版权声明、个性签名、空行等
 */

import 'package:flutter_24/pages/dragableGridview/packages/dragablegridviewbin.dart';

class ItemBin extends DragAbleGridViewBin {
  ItemBin(this.data);

  String data;

  @override
  String toString() {
    return 'ItemBin{data: $data, dragPointX: $dragPointX, dragPointY: $dragPointY, lastTimePositionX: $lastTimePositionX, lastTimePositionY: $lastTimePositionY, containerKey: $containerKey, containerKeyChild: $containerKeyChild, isLongPress: $isLongPress, dragAble: $dragAble}';
  }
}
